const laberinto = document.getElementById('laberinto');
const poemaCompleto = document.getElementById('poemaCompleto');
const imagenError = document.getElementById('imagenError');

// Poema dividido en párrafos
const parrafos = [
    "El reflejo en el espejo solo mostraba a esa chiquilla, que simplemente fantaseaba con algún día volar a las estrellas, tocar la luna y poder bailar con ella.",
    "Al ir creciendo, los sueños de esa niña poco a poco desaparecieron, sus anhelos y fantasías en recuerdo se convirtieron.",
    "Dentro de sí y sin darse cuenta un demonio fue apareciendo, lo que consumó su tierno y dulce pensamiento.",
    "Algunas noches frías los ideales le perseguían, esos bellos deseos que en su infancia eran vida.",
    "Pero el dolor, el rencor y la ira a ese demonio atraían, haciéndose más fuerte con el llanto y la melancolía.",
    "Un día sin esperarlo brotó una fuerza sobrenatural, que crecía en su vientre con un poder tal que, que a ese demonio logró derrotar.                                             Esa pequeña fuerza al principio causó dolor, pero con nombre propio a esa chiquilla llegó, para sacarla del letargo que la dominaba y como un arcoíris su vida de color llenaba",
    "Esa pequeña fuerza al principio causó dolor, pero con nombre propio a esa chiquilla llegó, para sacarla del letargo que la dominaba y como un arcoíris su vida de color llenaba."
];

// Configuración de laberinto
const mazeSize = 15;
const maze = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1],
    [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1], // 2: Celda de salida
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
];

// Posiciones de los párrafos
const path = [
    { x: 1, y: 1, paragraph: 0 },
    { x: 1, y: 5, paragraph: 1 },
    { x: 2, y: 3, paragraph: 2 },
    { x: 3, y: 7, paragraph: 3 },
    { x: 4, y: 11, paragraph: 4 },
    { x: 6, y: 13, paragraph: 5 },
    { x: 7, y: 13, paragraph: 6 }
];

let playerPosition = { x: 1, y: 1 };
let nextParagraphIndex = 0;

// Generar el laberinto visual
function createMaze() {
    laberinto.innerHTML = '';
    for (let i = 0; i < maze.length; i++) {
        for (let j = 0; j < maze[i].length; j++) {
            const cell = document.createElement('div');
            cell.classList.add('celda');
            cell.dataset.x = i;
            cell.dataset.y = j;
            if (maze[i][j] === 1) {
                cell.classList.add('pared');
            } else if (maze[i][j] === 2) {
                cell.classList.add('salida');
            }
            
            // Marcar celdas con párrafos
            if (path.some(p => p.x === i && p.y === j)) {
                cell.classList.add('parrafo');
            }
            
            // Posicionar al jugador
            if (i === playerPosition.x && j === playerPosition.y) {
                cell.classList.add('jugador');
            }
            laberinto.appendChild(cell);
        }
    }
}

document.addEventListener('keydown', movePlayer);

function movePlayer(event) {
    const { x, y } = playerPosition;
    let newX = x, newY = y;

    switch (event.key) {
        case 'ArrowUp': newX = x - 1; break;
        case 'ArrowDown': newX = x + 1; break;
        case 'ArrowLeft': newY = y - 1; break;
        case 'ArrowRight': newY = y + 1; break;
    }

    if (isWithinBounds(newX, newY) && maze[newX][newY] !== 1) {
        playerPosition = { x: newX, y: newY };
        checkForParagraph();
        createMaze();
    } else {
        showErrorImage();
    }
}

function checkForParagraph() {
    const currentPath = path.find(p => p.x === playerPosition.x && p.y === playerPosition.y);
    if (currentPath) {
        poemaCompleto.innerHTML += `<p>${parrafos[currentPath.paragraph]}</p>`;
        nextParagraphIndex++;
        // Ocultar el poema completo al recoger un nuevo párrafo
        poemaCompleto.style.display = 'block'; 
        setTimeout(() => {
            poemaCompleto.style.display = 'none'; // Ocultar después de mostrar
        }, 1000000); // Mostrar por 3 segundos
    }

    // Verificar si se ha llegado a la salida
    if (maze[playerPosition.x][playerPosition.y] === 2) {
        mostrarPoemaCompleto();
    }
}

function isWithinBounds(x, y) {
    return x >= 0 && x < maze.length && y >= 0 && y < maze[0].length;
}

function showErrorImage() {
    imagenError.style.display = 'block'; // Mostrar imagen de error
    setTimeout(() => {
        imagenError.style.display = 'none'; // Ocultar después de 5 segundos
    }, 5000);
}

function mostrarPoemaCompleto() {
    const textoCompleto = parrafos.join(' '); // Juntar todos los párrafos
    poemaCompleto.innerHTML = `<div class="rainbow-text">${textoCompleto}</div>`;
    poemaCompleto.style.display = 'block'; // Mostrar poema completo
}

// Función para cambiar fondo
function cambiarFondo() {
    const fondos = [
        '#f0f0f0', 
        '#add8e6', 
        '#ffe4e1', 
        '#e6e6fa', 
        '#ffebcd'
    ];
    document.body.style.backgroundColor = fondos[Math.floor(Math.random() * fondos.length)];
}

// Inicializar el laberinto
createMaze();
